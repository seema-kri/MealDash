--Is delivery time trending better or worse over time?
SELECT 
    Order_Date,
    AVG([Time_taken _min_]) AS Daily_Avg_Delivery_Time,
    AVG(AVG([Time_taken _min_])) OVER (
        ORDER BY Order_Date 
        ROWS BETWEEN 6 PRECEDING AND CURRENT ROW
    ) AS Rolling_7Day_Avg
FROM MealDash_Clean
GROUP BY Order_Date
ORDER BY Order_Date;