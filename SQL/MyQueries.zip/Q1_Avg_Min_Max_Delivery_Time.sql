SELECT TOP 1 * FROM MealDash_Clean;

SELECT 
    AVG([Time_taken _min_]) AS Avg_Delivery_Time,
    MIN([Time_taken _min_]) AS Min_Delivery_Time,
    MAX([Time_taken _min_]) AS Max_Delivery_Time
FROM MealDash_Clean;
