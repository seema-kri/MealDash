--Which city has the slowest average delivery time?
select City,avg([Time_taken _min_]) as avg_del_time,
count(*) as total_orders
from MealDash_Clean
group by City
order by avg_del_time DESC