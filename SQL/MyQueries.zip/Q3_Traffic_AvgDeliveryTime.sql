--does road traffic density affect delivery time?

select Road_traffic_density,avg([Time_taken _min_]) as avg_del_time,
count(*) as total_orders
from MealDash_Clean
group by Road_traffic_density
order by avg_del_time DESC