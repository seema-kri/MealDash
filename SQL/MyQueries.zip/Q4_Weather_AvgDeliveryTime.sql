--Does weather condition affect delivery time?

select Weather_conditions,avg([Time_taken _min_]) as avg_del_time,
count(*) as total_orders
from MealDash_Clean
group by Weather_conditions
order by avg_del_time desc