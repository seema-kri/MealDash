--Does delivery distance affect delivery time?
SELECT 
    CASE 
        WHEN Distance_km <= 5 THEN '0-5 km'
        WHEN Distance_km <= 10 THEN '5-10 km'
        WHEN Distance_km <= 15 THEN '10-15 km'
        ELSE '15+ km'
    END AS Distance_Bucket,
    AVG([Time_taken _min_]) AS Avg_Delivery_Time,
    COUNT(*) AS Total_Orders
FROM MealDash_Clean
GROUP BY 
    CASE 
        WHEN Distance_km <= 5 THEN '0-5 km'
        WHEN Distance_km <= 10 THEN '5-10 km'
        WHEN Distance_km <= 15 THEN '10-15 km'
        ELSE '15+ km'
    END
ORDER BY Distance_Bucket;