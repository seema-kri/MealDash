--Do certain vehicle types deliver faster than others?
select Type_of_vehicle,avg([Time_taken _min_]) as avg_del_time,
count(*) as total_orders
from MealDash_Clean
group by Type_of_vehicle
order by avg_del_time desc;