--Does handling multiple deliveries in one trip slow delivery time down?

SELECT 
    multiple_deliveries,
    AVG([Time_taken _min_]) AS Avg_Delivery_Time,
    COUNT(*) AS Total_Orders
FROM MealDash_Clean
WHERE multiple_deliveries IS NOT NULL
GROUP BY multiple_deliveries
ORDER BY multiple_deliveries;