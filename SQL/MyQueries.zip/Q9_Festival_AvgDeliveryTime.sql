--Are festival days slower than normal days?

SELECT 
    Festival,
    AVG([Time_taken _min_]) AS Avg_Delivery_Time,
    COUNT(*) AS Total_Orders
FROM MealDash_Clean
GROUP BY Festival
ORDER BY Avg_Delivery_Time DESC;